<header>
   <div class="container">
      <div class="header-content">
         <a href="<?= base_url('/'); ?>" class="logo"> <img src="<?= base_url('assets/img/govt_desk.webp'); ?>" alt="Sarkari Result" loading="lazy"></a>
         <div class="search-box">
            <input type="text" placeholder="🔍 Search jobs, results, admit cards..." id="searchInput">
            <button onclick="searchJobs()">Search</button>
         </div>
        <!-- Custom dropdown with only Indian languages -->
		<div id="google_translate_element" class="custom-gtranslate"></div> 

      </div>
   </div>
</header>
