
<nav>
    <div class="nav-container">
        <a href="<?= base_url('/'); ?>" class="logo">
            <img src="<?= base_url('assets/img/govt_desk.webp'); ?>" alt="Sarkari Result" loading="lazy">
        </a>
 
        <!-- Hamburger Menu Icon -->
        <button class="menu-toggle" id="menu-toggle" aria-label="Toggle navigation">
            ☰
        </button>
 
        <!-- Navigation Links -->
        <ul class="nav-links" id="nav-links">
            <li><a href="<?= base_url('/') ?>">🏠 Home</a></li>
            <li><a href="<?= base_url();?>">💼 Latest Jobs</a></li>
            <li><a href="<?= base_url('results');?>">📊 Results</a></li>
            <li><a href="<?= base_url('admit-cards');?>">🎫 Admit Cards</a></li>
            <li><a href="<?= base_url('answer-keys');?>">🔑 Answer Keys</a></li>
            <li><a href="<?= base_url('syllabus');?>">📚 Syllabus</a></li>
            <li><a href="<?= base_url('/contact-us') ?>">📞 Contact</a></li>
        </ul>
 
        <!-- Language Dropdown -->
        <div id="google_translate_element" class="custom-gtranslate"></div>
    </div>
</nav>
      
