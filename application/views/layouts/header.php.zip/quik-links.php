<div class="sidebar">
                    <div class="sidebar-section glow">
                        <h3 class="section-title">⚡ Quick Links</h3>
                        <ul class="quick-links">
                            <li><a href="<?= base_url('results');?>">📋 Result Status</a></li>
                            <li><a href="#">📝 Application Status</a></li>
                            <li><a href="#">🎯 Cut-off Marks</a></li>
                            <li><a href="#">📚 Previous Papers</a></li>
                            <li><a href="#">📖 Study Material</a></li>
                            <li><a href="#">💼 Job Alerts</a></li>
                        </ul>
                    </div>

                    <div class="sidebar-section">
                        <h3 class="section-title">🏆 Popular Exams</h3>
                        <ul class="quick-links">
                            <li><a href="#">🎓 SSC CGL</a></li>
                            <li><a href="#">🏛️ IBPS PO</a></li>
                            <li><a href="#">🚂 RRB NTPC</a></li>
                            <li><a href="#">⚖️ UPSC CSE</a></li>
                            <li><a href="#">🏦 SBI Clerk</a></li>
                        </ul>
                    </div>

                    <div class="sidebar-section">
                        <h3 class="section-title">📊 Live Statistics</h3>
                        <p><strong>Total Jobs:</strong> <span class="stat-number" id="totalJobs">45,678</span></p>
                        <p><strong>Active Users:</strong> <span class="stat-number" id="activeUsers">2,34,567</span></p>
                        <p><strong>Results Today:</strong> <span class="stat-number" id="resultsToday">23</span></p>
                        <div class="loading-spinner" style="display: none;" id="loadingSpinner"></div>
                    </div>
                </div>